export interface Fornecedor {
    id?: number;
    nome: string;
    cnpj: string;
    fone: string;
}