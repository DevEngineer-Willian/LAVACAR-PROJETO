import { Injectable } from '@angular/core';
import Dexie, { Table } from 'dexie';
import {Fornecedor} from '../models/fornecedor.model';

@Injectable({
  providedIn: 'root'
})
export class DbService extends Dexie {
    fornecedores!: Table<Fornecedor, number>;

  constructor() { 
    super('LavacarDB');
    this.version(1).stores({
      fornecedores: '++id, nome, fone',
    });
  }
}
